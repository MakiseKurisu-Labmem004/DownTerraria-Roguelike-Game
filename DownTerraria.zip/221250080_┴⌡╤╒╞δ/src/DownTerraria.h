#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <math.h>
#include "SDL2/SDL.h"
#include "SDL2/SDL_ttf.h"
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_mixer.h"
#undef main

typedef struct OBJECT
{
    SDL_Rect ObjectRect;
    SDL_Point ObjectCenter;
    int Hp;        // 敌人,可破坏地形
    int Distance;  // 记录 子弹 已经走了多远
    bool Toward_X; // 速度的方向
    int Damage;    // 子弹,敌人 伤害
    int Speed;
    int Which;
    int Alpha;
    int Type;        // 一共有几种
    bool AppearLoop; // 是否为type循环出现的个体
    int X;
    int Y;
    struct OBJECT *Next;
} OB;

typedef struct ENEMY
{
    int Which_Enemy;
    SDL_Rect EnemyRect;
    SDL_Point Point1;
    SDL_Point Point2;
    SDL_Point Point3;
    SDL_Point Point4;
    SDL_Point Point5;
    SDL_Point Point6;
    SDL_Point ExPoint;
    bool Turn_To_Right;
    bool CanFly;
    bool CanJump;
    bool CanShoot;
    int W;
    int H;
    int Hp;
    int Damage;
    int Speed;
    int Which;
    int Type;
    int Delay;
    int ActionDelay;
    int Distance;
    int Music;
    double Angle;
    bool Droping;
    bool DropRun;
    int JumpSpeed;
    struct ENEMY *Next;
} ENEMY;

typedef struct LAND
{
    SDL_Rect LandRect;
    int Land_X;
    int Land_Y;
    int Which;
    bool BeDamaged;
    bool PassBullet;
    bool OnIt;
    bool CanExertEnemy;
    int Hp;
    struct LAND *Next;
} LAND;

typedef struct ITEM
{
    SDL_Rect ItemRect;
    int Which_Item;
    int Index;
    bool BeBought;
    int Au;
    int Ag;
    int Cu;
    struct ITEM *Next;
} ITEM;

enum Hp
{
    BulletHp = 1,
    BulletFireHp = 1,
};
enum Speed
{
    BulletSpeed = 40,
};
enum Type
{
    BulletType = 1,
    BulletFireType = 3,
    EmptyType = 5,
};

static OB *Me_Bullet = NULL;
static OB *Star = NULL;
static OB *Me_BulletFire = NULL;
static OB *Die = NULL;
static OB *Empty = NULL;
static OB *Finalline = NULL;
static OB *Finalline2 = NULL;
static OB *RandomBuff = NULL;
static LAND *Land = NULL;
static LAND *Stone = NULL;
static ENEMY *Enemy = NULL;
static ENEMY *Enemy2 = NULL;
static ENEMY *Enemy3 = NULL;
static ENEMY *Enemy4 = NULL;
static ENEMY *Money = NULL;
static ENEMY *NPC = NULL;
static ENEMY *EnemyBullet = NULL;
static ENEMY *Boss = NULL;
static ENEMY *BossEye = NULL;
static ITEM *ItemsOnSale = NULL;
ITEM *Items[13] = {NULL};

static SDL_Point Point_1;
static SDL_Point Point_2;
static SDL_Point Point_L;
static SDL_Point Point_R;
static SDL_Point Point_LL;
static SDL_Point Point_RR;
static SDL_Point Point_D;
static SDL_Point Point_DD;
static SDL_Point Point_DDD;
static SDL_Window *Window = NULL;
static SDL_Renderer *Renderer = NULL;
static SDL_Event MainEvent;
static SDL_Rect MeRect;
static SDL_Rect BackRect;
static SDL_Rect Back2Rect;
static SDL_Rect Back3Rect;
static SDL_Rect TitleRect;
static SDL_Rect HpRect;
static SDL_Rect ClipRect;
static SDL_Rect LevelRect;
static SDL_Rect BiuRect;
static SDL_Rect TipRect;
static SDL_Rect TipRect;
static SDL_Rect Num1Rect;
static SDL_Rect Num2Rect;
static SDL_Rect Num3Rect;
static SDL_Rect Num4Rect;
static SDL_Rect ScoreRect;
static SDL_Rect ScoreNumRect;
static SDL_Rect GradeRect;
static SDL_Rect RetryRect;
static SDL_Rect ExitRect;
static SDL_Rect LifeRect;
static SDL_Rect BloodRect;
static SDL_Rect AttackRect;
static SDL_Rect AccountRect;
static SDL_Rect OverRect;
static SDL_Surface *FinallineSurface[2] = {NULL};
static SDL_Surface *Finalline2Surface[2] = {NULL};
static SDL_Surface *BulletSurface[10] = {NULL};
static SDL_Surface *FireSurface[4] = {NULL};
static SDL_Surface *DieSurface[9] = {NULL};
static SDL_Surface *EmptySurface[6] = {NULL};
static SDL_Surface *LandSurface[50] = {NULL};
static SDL_Surface *PlatSurface[5] = {NULL};
static SDL_Surface *Enemy1LSurface[5] = {NULL};
static SDL_Surface *Enemy1RSurface[5] = {NULL};
static SDL_Surface *Enemy2LSurface[3] = {NULL};
static SDL_Surface *Enemy2RSurface[3] = {NULL};
static SDL_Surface *Enemy3Surface[4] = {NULL};
static SDL_Surface *Enemy4Surface[4] = {NULL};
static SDL_Surface *CuSurface[9] = {NULL};
static SDL_Surface *AgSurface[9] = {NULL};
static SDL_Surface *AuSurface[9] = {NULL};
static SDL_Surface *RandomBuffSurface[8] = {NULL};
static SDL_Surface *LoveSurface[2] = {NULL};
static SDL_Surface *NPCLSurface[5] = {NULL};
static SDL_Surface *NPCRSurface[5] = {NULL};
static SDL_Surface *ItemsSurface[13] = {NULL};
static SDL_Surface *TipSurface[6] = {NULL};
static SDL_Surface *StarSurface[2] = {NULL};
static SDL_Surface *EnemyBulletSurface[3] = {NULL};
static SDL_Surface *BossBulletSurface[4] = {NULL};
static SDL_Surface *BossBodySurface[10] = {NULL};
static SDL_Surface *BossEyeSurface[2] = {NULL};
static SDL_Surface *BossItemSurface[12] = {NULL};

static Mix_Music *BGM[5] = {NULL};
static Mix_Chunk *music1;
static Mix_Chunk *music2;
static Mix_Chunk *music3;
static Mix_Chunk *music4;
static Mix_Chunk *music5;
static Mix_Chunk *music6;
static Mix_Chunk *music7;
static Mix_Chunk *music8;
static Mix_Chunk *music9;
static Mix_Chunk *music10;
static Mix_Chunk *music11;
static Mix_Chunk *music12;
static Mix_Chunk *music13;
static Mix_Chunk *music14;
static Mix_Chunk *music15;
static Mix_Chunk *music16;
static Mix_Chunk *music17;
static Mix_Chunk *music18;
static Mix_Chunk *music19;
static Mix_Chunk *music20;
static Mix_Chunk *music21;
static Mix_Chunk *music22;
static Mix_Chunk *music23;
static Mix_Chunk *music24;
static Mix_Chunk *music25;
static Mix_Chunk *music26;
static Mix_Chunk *music27;
static Mix_Chunk *music28;
static Mix_Chunk *music29;
static clock_t FDurTime;

static TTF_Font *MoneyFont = NULL;
static TTF_Font *ScoreFont = NULL;
static SDL_Color MoneyColor = {255, 255, 255, 0};

bool Buff[13] = {false, false, false, false, false, false, false, false, false, false, false, false, false};

void QUIT();
void Free(SDL_Surface *SurList[], int n);
void FIRST_LOAD();     // 加载主界面的行为
void LOAD_STAND();     // 加载站立姿态
void LOAD_RUN();       // 加载跑姿态
void LOAD_ONSKY();     // 加载空中姿态
void LOAD_FIRSTBACK(); // 加载初始界面
void LOAD_TITLE();     // 加载游戏名
void LOAD_PREPARE();   // 加载开始前的下落与技能选择,关卡?,技能???,drop
void LOAD_LEVEL();
void LOAD_TIP(int x, int y);
void LOAD_BIU();
void LOAD_BACK1();
void LOAD_BACK2();
void LOAD_BACK3();
void LOAD_ATTACK();
void LOAD_HP_CLIP();
void LOAD_ACCOUNT();
void LOAD_RANDOM_ITEM();
void Modify_Account(int au, int ag, int cu, bool add);
void Judge_Buy();
void StartBuff(int which);
void RANDOM_BUFF();
void LOAD_INTERACTION();
void LOAD_MONEY1();
void LOAD_MONEY2();
void LOAD_MONEY3();
void LOAD_MONEY4();
void LOAD_ME();
void LOAD_GAME();
void LOAD_BOSS();
void COPY_OBJECT();
void MOVE_OBJECT();
void ReLoadList();
void Judge_MeOnEnemy(ENEMY **List);
void PrintList(OB **List, SDL_Surface *SurList[]);
void PrintWordList(OB **List, SDL_Surface *SurList[]);
void Print_Item_List(ITEM **List, SDL_Surface *SurList[]);
void Print_Land_List(LAND **List, SDL_Surface *SurList[]);
void PrintExList(ENEMY **List, SDL_Surface *SurListL[], SDL_Surface *SurListR[]);
void PrintBulletList(ENEMY **List, SDL_Surface *SurList[]);
void PrintBossBody(ENEMY **List, SDL_Surface *SurList[]);
void PrintBossEye(ENEMY **List, SDL_Surface *SurList[]);
void PrintBossLife();
void Print_Enemy_List(ENEMY **List, SDL_Surface *SurListL[], SDL_Surface *SurListR[]);
void Print_Money_List(ENEMY **List, SDL_Surface *SurList4[], SDL_Surface *SurList3[], SDL_Surface *SurList2[], SDL_Surface *SurList5[]);
void Print_NPC_List(ENEMY **List, SDL_Surface *SurListL[], SDL_Surface *SurListR[]);
void LoadResource();
void LoadResource2();
void LoadResource3();
bool Return_Init_X(LAND **List);
bool Judge_Drop(LAND **List);
void Judge_Enemy_Turn(LAND **List1, LAND **List2, ENEMY *E);
bool Judge_Enemy_Drop(LAND **List1, LAND **List2, ENEMY *E);
void Judge_BulletOnEnemy(OB **List, ENEMY **EList);
int Judge_CanInteract(ENEMY **List);
void AddNode(OB **List, OB *NewNode);
void Add_Item_Node(ITEM **List, ITEM *NewNode);
void Add_Land_Node(LAND **List, LAND *NewNode);
void Add_Enemy_Node(ENEMY **List, ENEMY *NewNode);
void Enemy_Normal_Run(ENEMY *Now);
void Enemy_Drop_Run(ENEMY *Now);
void Enemy_Fly(ENEMY *Now);
void Enemy_Jump(ENEMY *Now);
void Move_Enemy_Bullet(ENEMY **List, int Distance);
void Move_Boss(ENEMY **List, int Distance);
void Move_BossItem(ENEMY **List, int Distance);
void Collect_Money(ENEMY **List);
void CreateBullet(int x);
void CreateStar();
void CreateEmpty();
void CreateFinalline(int y);
void CreateFinalline2(int y);
void CreateFire(int x, int y);
void CreateDie(int x, int y);
void CreatePlatform(int x, int y);
void CreatePrepare1(int y);
void CreatePrepare2(int y);
void CreateStone1(int y);
void CreateStone2(int y);
void CreateStone3(int y);
void CreateStone4(int y);
void CreateStone5(int y);
void CreateStone6(int y);
void CreateStone7(int y);
void CreateStone8(int y);
void CreateStone9(int y);
void CreateStone10(int y);
void CreateStone11(int y);
void CreateStone12(int y);
void CreatePlat1(int y);
void CreatePlat2(int y);
void CreateEnemy1(int x, int y);
void CreateEnemy2(int x, int y);
void CreateEnemy3(int x, int y);
void CreateEnemy4(int x, int y);
void CreateEnemy5(int x, int y);
void CreateEnemy6(int x, int y);
void CreateEnemy7(int x, int y);
void CreateEnemy8(int x, int y);
void CreateEnemy9(int x, int y);
void CreateEnemy10(int x, int y, int angle);
void CreateEnemy11(int x, int y, int angle);
void CreateMoney(int x, int y);
void CreateNPC(int x, int y);
void CreateFinalNPC(int y);
void Random_Create(int i, int y);
void BodySkill();
void RandomBarriar(int y);
void LOAD_RANDOM_BARRIAR();
void LOAD_RANDOM_ENEMY(LAND **List, int r);
void MoveNode(OB **List);
void MoveNodePlus(OB **List, bool Toward_X, int Speed);
void Move_Land_Node(LAND **List, int Distance);
void Move_Fire_Node(OB **List, int Distance);
void Move_Enemy_Node(ENEMY **List, int Distance);
bool Modify_DISTANCE();
void Judge_BulletOnLand(OB **List, LAND **SList);
int Judge_Enemy_Crash(LAND **List, ENEMY *E);
LAND *Create_Land_Node(int Land_X, int Land_Y, int Which, bool BeDamaged, bool PassBullet, bool CanEcertEnemy, int Hp);
OB *CreateNode(int Hp, int Distance, bool Toward_X, int Damage, int Speed, int Which, int X, int Y, int Type, bool AppearLoop);
ENEMY *Create_Enemy_Node(int Which_Enemy, int Hp, int Damage, int Speed, int JumpSpeed, int Which, int Type, int X, int Y, bool CanFly, bool CanJump, bool CanShoot, int Music, int H, int W);
ENEMY *Create_DropEnemy_Node(int Which_Enemy, int Hp, int Damage, int Speed, int JumpSpeed, int Which, int Type, int X, int Y, bool CanFly, bool CanJump, bool CanShoot, int Music, int H, int W);
ITEM *Create_Item_Node(int Which_Item, int Index, int Au, int Ag, int Cu);
void Remove_Enemy_Node(ENEMY **List);
void Remove_Land_Node(LAND **List);
void RemoveNode(OB **List);
void Remove_Item_Node(ITEM **List);
void UpdatePoint();
void Update_E1_Point(ENEMY *Now);
void Update_E2_Point(ENEMY *Now);
void UpdatePointJ();
bool Judge_BackMove();   // 判断主界面什么时候移动
void Judge_BackChange(); // 判断主界面什么时候切换
void Back_Change();      // 主界面切换
void Judge_Enter();      // 判定线
void Judge_EnterNextLevel();
void ControlFPS(clock_t StartTime);
void JudgeGameOver();
void LOAD_SCORE();
void ReTry();

bool BeingInvicible = false;
bool GameOver = false;
bool RemoveTime = false;
int InvicibleTime = 0;
int MaxInvicibleTime = 20;
int OverRand;
int Init_X;
int Init_Y;
int DISTANCE = 0;
int CurrentLevel = 1; // 关卡进行到第几阶段
int Me_HP = 4;
int MAXHP = 4;
int Rand;
int InitLand_Y = 720;
int LastRand;
int NPCLastRand = -1;
int WhichNPC = 0;
bool ClickOnce = true;
bool HaveChat = false;
int ItemIndex = 0;
bool HaveRob = false;
bool Buying = false;
bool Choosing = false;
bool HaveItems = false;
bool CanInteract = false;
bool Interacting = false;
bool Judge_Start = false;   // 是否开始
bool Judge_Right = false;   // 是否右移
bool Judge_Left = false;    // 是否左移
bool Judge_Jump = false;    // 是否跳跃
bool Hit_Twice = false;     // 判断是第几次敲空格
bool Judge_BackLeft = true; // 判断主界面是图片的哪个部分
bool Back_Changing = false; // 判断主界面是否正在切换
bool Judge_Entering = true;
bool Entering_NextLevel = false;
bool Entering_NextLevel2 = false;
bool RedioOnce = false;
bool EmptyAppear = true;
bool biu = false;
bool NextJudge = false;
bool modify = false;
bool StartMove = false;
bool StoreHeart = false;
int BOSS_LIFE = 4000;
int BOSS_BLOOD = 4000;
bool Start_BOSS = false;
int Drop_Distance = 0;
int Body_Distance = 200;
int Eye_Distance1 = 0;
int Eye_Distance2 = 300;
int Last_Random_Buff = 0;
int biu_Which = 10;
int Stand_Which = 1;
int StandDelay = 0;   // 站立停顿
char Look_To_R = 'R'; // 判断人物朝向
double Me_X = 300;    // 人物的X坐标
double Me_Y = 360;    // 人物的Y坐标
int Back_X = 0;       // 背景X坐标
int Back_Y = 0;       // 背景Y坐标
int Back_Pre1_Y = 0;
int Back_1_Y = -400;
int Back_2_Y;
int Back_3_Y = 1000;
int Me_Speed = 10; // 人物的速度
int Run_Which = 1; // 决定跑步到第几个姿态
int Run_Delay = 0; // 跑步停顿
int Run_M_Delay = 6;
char FileName[40];
int Jump_Delay = 0;
int Jump_Which = 1; // 跳跃的姿态
int Jump_Speed = 30;
int Gravity = 3;
int Jump_Delay_Limit[4] = {3, 7, 4, 6}; // 用于空中姿态转换
int Title_Which = 0;                    // 浮现游戏名
int Title_Delay = 0;
int Title_X = 93;           // 注意 Title_X 和 Back_X 的相对距离不变
int Title_Y = 100;          // 注意 Title_Y 和 Back_Y 的相对距离不变
bool Title_Appear = false;  // 判断什么时候出现游戏名
bool Attacking = false;     // 判定是否正在攻击
bool Have_Hit_Once = false; // 判断是否已经按下一次空格
bool Must_Hit_Space = true; // 阻止连续跳跃
int Attack_Which = 1;
int Attack_Speed = -6;
int Attack_Delay = 0;
int Bullet_Delay = 4;
bool On_Land = true;          // 游戏开始时生效,走下去On_Land为true,跳在空中不改变,attack由On_Land和Have_Hit_Once共同决定
bool Judge_Preparing = false; // 开始游戏前的下落和选择技能时间
int Bullet_Num = 8;           // 弹夹初始容量,子弹与背景相对位置不变
int Bullet_Consume = 0;
int PreRound = 5;
int Level_Which = 1;
int Level_Add = 1;
int Level_Delay = 0;
bool Level_Finish = false;
int BulletDistance = 250;
int BulletDamage = 10;
int arr1[12] = {100, 400, 100, 400, 200, 400, 100, 400, 100, 400, 100, 400};
int arr2[12] = {500, 500, 700, 600, 600, 600, 400, 400, 400, 400, 300, 300};
int arr3[12] = {100, 550, 100, 550, 100, 500, 100, 500, 100, 550, 100, 500};
int arr4[12] = {150, 250, 150, 150, 150, 150, 50, 50, 50, 50, 50, 50};
int arr5[12] = {150, 500, 150, 500, 150, 550, 150, 550, 150, 500, 150, 550};
int arr6[12] = {150, 250, 150, 150, 150, 150, 50, 50, 50, 50, 50, 50};
int arr7[12] = {100, 350, 100, 400, 100, 400, 150, 350, 150, 350, 150, 350};
int arr8[12] = {500, 500, 350, 350, 550, 550, 250, 150, 100, 300, 100, 100};
int arr9[12] = {300, 550, 300, 350, 300, 350, 100, 550, 100, 550, 100, 550};
int arr10[12] = {500, 500, 350, 350, 550, 550, 250, 150, 100, 300, 100, 100};
int arr11[12] = {250, 200, 250, 200, 250, 200, 300, 200, 200, 200, 300, 200};
int arr12[12] = {750, 720, 600, 600, 800, 800, 500, 400, 400, 550, 350, 350};
int arr13[12] = {200, 200, 200, 300, 200, 400, 100, 400, 100, 400, 100, 400};
int arr14[12] = {600, 550, 700, 600, 550, 550, 350, 350, 350, 350, 350, 350};
int arr15[12] = {100, 500, 100, 500, 100, 500, 100, 550, 100, 500, 100, 500};
int arr16[12] = {250, 250, 250, 250, 250, 250, 50, 50, 50, 50, 50, 50};
int arr17[12] = {150, 550, 150, 550, 150, 550, 150, 500, 150, 550, 150, 550};
int arr18[12] = {250, 250, 250, 250, 250, 250, 50, 50, 50, 50, 50, 50};
int arr19[12] = {100, 500, 100, 550, 100, 550, 100, 550, 100, 550, 100, 550};
int arr20[12] = {300, 300, 300, 300, 300, 300, 100, 100, 100, 100, 100, 100};
int ENEMY1_1_Hight = 31;
int ENEMY1_1_Weight = 40;
int ENEMY1_2_Hight = 28;
int ENEMY1_2_Weight = 41;
int ENEMY1_3_Hight = 39;
int ENEMY1_3_Weight = 50;
int ENEMY2_2_Hight = 37;
int ENEMY2_2_Weight = 70;
int ENEMY2_3_Hight = 34;
int ENEMY2_3_Weight = 50;
int ENEMY2_4_Hight = 80;
int ENEMY2_4_Weight = 44;
int ENEMY3_3_Hight = 39;
int ENEMY3_3_Weight = 40;
int Cu = 0;
int Ag = 0;
int Au = 0;
int Pt = 0;